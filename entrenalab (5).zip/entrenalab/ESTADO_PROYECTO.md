# Estado del proyecto — EntrenaLab

_Generado el 2 de julio de 2026, para retomar el desarrollo en otra herramienta de IA._

## Qué es

EntrenaLab es una app web de cálculos de entrenamiento y generación de rutinas, **100% HTML/CSS/JS puro, sin frameworks, sin backend, sin costo de API**. Corre entera en el navegador del usuario, incluida la exportación a PDF.

## Estado: completo, los 7 módulos del README implementados

| # | Módulo | Estado |
|---|---|---|
| 01 | 1RM (Epley, Brzycki, Lander, Lombardi, Mayhew et al.) | ✅ |
| 02 | DOTS / Wilks (fuerza relativa) | ✅ |
| 03 | TDEE y macros (Mifflin-St Jeor) | ✅ |
| 04 | FC y zonas (Tanaka/clásica + Karvonen) | ✅ |
| 05 | 9 tests de campo (Cooper, Course Navette, VAM-EVAL, 5 min, 6MWT, Queens, Harvard, Ruffier-Dickson, UKK) | ✅ |
| 06 | Generador de rutinas (split semanal por MEV/MAV/MRV, Israetel et al. 2019) | ✅ |
| 07 | Herramienta entrenador (ficha cliente) + exportación PDF (jsPDF) | ✅ |

**49/49 tests unitarios en verde** (Vitest, uno por módulo de fórmulas puras).

## Arquitectura

```
entrenalab/
├── index.html                  # Shell de la app, todas las vistas (tabs)
├── css/styles.css               # Sistema de diseño (ver abajo)
├── js/
│   ├── formulas/                 # Lógica pura, SIN DOM, testeada con Vitest
│   │   ├── oneRM.js
│   │   ├── strengthScore.js
│   │   ├── energy.js
│   │   ├── heartRate.js
│   │   ├── fieldTests.js
│   │   └── routineGenerator.js
│   ├── ui/                       # Wiring de DOM, sin lógica de cálculo propia
│   │   ├── calculators.js        # 1RM, DOTS/Wilks, TDEE, FC
│   │   ├── fieldTestsUI.js       # selector dinámico de los 9 tests de campo
│   │   ├── routineBuilder.js     # generador de rutinas + export PDF
│   │   ├── trainerTool.js        # ficha de cliente (combina 1RM + rutina + PDF)
│   │   ├── pdfExport.js          # motor genérico de reportes PDF (jsPDF + autotable)
│   │   ├── references.js         # datos y render de la pestaña Referencias
│   │   └── refUtils.js           # helpers UI compartidos (formato, formula-tags, errores)
│   └── app.js                    # navegación entre tabs, arranque
├── vendor/                        # jsPDF + jspdf-autotable vendorizados (offline), ver NOTICE.md
├── tests/                        # Vitest, uno por módulo de js/formulas/
├── .github/workflows/tests.yml   # CI: corre los tests en cada push/PR
├── REFERENCIAS.md                # Bibliografía completa (sincronizada con references.js)
├── package.json
└── LICENSE                       # MIT
```

**Regla de oro de la arquitectura:** `js/formulas/` es JS puro, sin tocar `document` ni `window`. Eso es lo que permite testearlo con Vitest sin entorno de navegador simulado, y lo que permite portar la lógica 1:1 a React/Next si el día de mañana se migra. `js/ui/` solo hace wiring de DOM y nunca calcula nada por su cuenta — siempre llama a una función de `js/formulas/`.

## Decisiones de diseño (por si hay que mantener consistencia)

- **Identidad visual:** "cuaderno de laboratorio de rendimiento" — fondo con grid milimetrado, tipografía Space Grotesk (display) + JetBrains Mono (datos/números), verde tipo "readout de instrumento" (`--readout: #3fae7f` sobre `--readout-bg: #12241d`) para resultados, tags de citación (`.formula-tag`) junto a cada resultado con la fuente de la fórmula usada. Todo definido en `css/styles.css` con custom properties.
- **Cada fórmula está citada:** autor, año, publicación, y una nota de alcance/limitaciones — tanto en el código (JSDoc arriba de cada función) como en `REFERENCIAS.md` y la pestaña "Referencias" de la app (`js/ui/references.js`). Si se agrega una fórmula nueva, hay que sumarla en los tres lugares.
- **Los coeficientes numéricos (DOTS, Wilks, Léger, UKK, Queens, etc.) fueron verificados con búsquedas web antes de codificarlos**, no se usó memoria del modelo sin chequear — son fáciles de confundir y el proyecto se vende como "basado en evidencia".
- **PDF:** se genera con jsPDF 2.5.2 + jspdf-autotable 3.8.2, vendorizadas en `vendor/` (ver `vendor/NOTICE.md` para versión/licencia/cómo actualizar) y cargadas como `<script>` local desde `index.html`. **La exportación a PDF ya funciona 100% offline**, verificado generando un PDF real sin red en un sandbox tipo navegador. Nota: `css/styles.css` sigue importando las tipografías Space Grotesk/JetBrains Mono desde Google Fonts (`fonts.googleapis.com`), así que la app en su conjunto todavía no es 100% offline — eso quedó fuera del alcance de esta tarea.
- **Generador de rutinas:** los landmarks MEV/MAV/MRV son de Israetel et al. (2019, serie de artículos de Renaissance Periodization), pero el reparto de sets por sesión y el armado de las plantillas de split (Full Body / PPL / Upper-Lower) son una síntesis práctica propia del proyecto, no una fórmula publicada — está aclarado explícitamente en `REFERENCIAS.md` para no atribuir de más.

## Responsive (hecho)

`css/styles.css` tiene ahora breakpoints en `768px` y `480px`, además del `640px` que ya existía para `.two-col`:

- **Nav de pestañas:** en ≤640px pasa de `flex-wrap` (apilaba en varias líneas y empujaba el contenido) a scroll horizontal (`overflow-x: auto`, `flex-wrap: nowrap`).
- **Tablas** (`.data-table`): cualquier contenedor que tenga una tabla como hijo directo (`div:has(> table.data-table)`, más `.readout` en general) tiene `overflow-x: auto` para scrollear en vez de romper el layout. `table.data-table { min-width: 340px }` evita que las columnas se aplasten.
- **Formularios:** `.field-grid` y `.radio-group` pasan a una columna en ≤640px; `button.primary` a `width: 100%` en ≤768px para mejor targeting táctil.
- **Tipografía/espaciado:** `main`, `.panel`, `.readout` y `.view-header h1`/`p` reducen padding y font-size en los dos breakpoints, incluido `.readout-value` (2.4rem → 1.9rem → 1.6rem).
- **Verificado con Playwright + Chromium real** (no solo CSS en papel) en 375/390px (mobile), 768px (tablet) y 1280px (desktop), en las vistas 1RM, Rutina, Entrenador y Tests de campo.

## Qué NO está hecho (posibles próximos pasos)

1. **Tests para `js/ui/`:** hoy solo hay tests de `js/formulas/` (lógica pura). El wiring de DOM (`calculators.js`, `trainerTool.js`, `pdfExport.js`, etc.) no tiene tests automatizados porque dependen de `window`/DOM y el proyecto no tiene entorno de navegador simulado configurado en Vitest (se podría sumar `jsdom` o `happy-dom`).
2. **Persistencia:** no hay `localStorage` ni cuentas de usuario (a propósito, ver roadmap de monetización en el `README.md` original — freemium con Supabase/Firebase Auth es la sugerencia ahí).
3. **Sin verificación visual real en navegador:** todo el trabajo se hizo con Vitest (lógica) y revisión manual de código/HTML; no se corrió un navegador real ni se sacó captura de pantalla del resultado final. Vale la pena abrir `index.html` y click-testear las 7 pestañas antes de darlo por 100% terminado.
4. Roadmap de monetización (freemium, plan entrenador, marca blanca real con paywall, integraciones Strava/Garmin, migración a Next.js) sigue siendo solo ideas en el README, no implementado — es intencional, el proyecto hoy es 100% gratuito y estático.

## Cómo correrlo

```bash
npm install
npm test          # 49 tests, Vitest
npx serve .        # o python3 -m http.server 5173
```

## Fuente de este documento

Este archivo resume una conversación de desarrollo con Claude (Anthropic) en la que se construyó el proyecto completo desde un README de especificación. El código completo está en el `.zip` entregado junto a este documento.
