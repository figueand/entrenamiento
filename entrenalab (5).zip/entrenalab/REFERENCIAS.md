# Referencias bibliográficas

Bibliografía completa de las fórmulas implementadas en EntrenaLab. Sincronizada con `js/ui/references.js` (pestaña "Referencias" de la app).

## 1RM (una repetición máxima)

| Fórmula | Cita | Alcance / limitaciones |
|---|---|---|
| Epley | Epley, B. (1985). *Poundage Chart*. Boyd Epley Workout. | Válida aprox. hasta 10-12 reps; sobreestima levemente a reps altas. |
| Brzycki | Brzycki, M. (1993). Strength Testing—Predicting a One-Rep Max from Reps-to-Fatigue. *Journal of Physical Education, Recreation & Dance*, 64(1). | Diverge matemáticamente a partir de 37 repeticiones (denominador ≤ 0). |
| Lander | Lander, J. (1985). Maximums Based on Reps. *NSCA Journal*, 6(6). | Similar precisión a Epley en rangos de 1-10 reps. |
| Lombardi | Lombardi, V.P. (1989). *Beginning Weight Training*. Wm. C. Brown Publishers. | Tiende a subestimar a reps bajas, sobreestimar a reps altas. |
| Mayhew et al. | Mayhew, J.L. et al. (1992). Muscular endurance repetitions to predict bench press strength in men of different training levels. *Journal of Sports Medicine and Physical Fitness*, 32(1). | Desarrollada específicamente para press de banca. |

## Fuerza relativa

| Fórmula | Cita | Alcance / limitaciones |
|---|---|---|
| DOTS | Konertz, T. (2019). *DOTS Formula*. Adoptada por USAPL, USPA, GPC. | Polinomio de 4º grado calibrado con datos de competencia 2010-2018. Más preciso que Wilks en pesos corporales extremos (<56 kg o >125 kg). |
| Wilks (clásico) | Wilks, R. (1994). *Wilks Coefficient*. | Estándar en powerlifting entre 1994 y ~2019. Sesgo conocido hacia lifters de peso medio. |

## Gasto energético

| Fórmula | Cita | Alcance / limitaciones |
|---|---|---|
| BMR — Mifflin-St Jeor | Mifflin, M.D., St Jeor, S.T., et al. (1990). A new predictive equation for resting energy expenditure in healthy individuals. *American Journal of Clinical Nutrition*, 51(2), 241-247. | Mejor validación en población general moderna que Harris-Benedict. Margen de error individual estimado ±10-15%. |

## Frecuencia cardíaca

| Fórmula | Cita | Alcance / limitaciones |
|---|---|---|
| FCmáx — Tanaka | Tanaka, H., Monahan, K.D., Seals, D.R. (2001). Age-predicted maximal heart rate revisited. *Journal of the American College of Cardiology*, 37(1), 153-156. | Más precisa en adultos que la fórmula clásica; desviación estándar ±7-10 lpm. |
| FCmáx — clásica | Fox, S.M., Naughton, J.P., Haskell, W.L. (1971). Physical activity and the prevention of coronary heart disease. | Ampliamente usada pero con mayor margen de error (±10-12 lpm). |
| Zonas — Karvonen | Karvonen, M.J., Kentala, E., Mustala, O. (1957). The effects of training on heart rate: a longitudinal study. *Annales Medicinae Experimentalis et Biologiae Fenniae*, 35(3), 307-315. | Método de frecuencia cardíaca de reserva (HRR); no reemplaza una prueba de esfuerzo directa. |

## Tests de campo de resistencia

| Test | Cita | Alcance / limitaciones |
|---|---|---|
| Cooper (12 min) | Cooper, K.H. (1968). A means of assessing maximal oxygen intake. *JAMA*, 203, 201-204. | Correlación fuerte (r≈0.9) con VO2max de laboratorio en población general. |
| Course Navette (Léger) | Léger, L.A., Mercier, D., Gadoury, C., Lambert, J. (1988). The multistage 20 metre shuttle run test for aerobic fitness. *Journal of Sports Sciences*, 6(2), 93-101. | Válida 8-45 años. Tiende a subestimar en adultos muy sedentarios (población de calibración universitaria). |
| VAM-EVAL | Cazorla, G., Léger, L. (1993). Test de vitesse maximale aérobie. | VO2max = 3.5 × VMA (km/h). Mejor correlación con corredores de ruta que la Course Navette al ser un test continuo sin cambios de dirección. |
| Test de 5 minutos | Heurística de campo de uso extendido en entrenamiento, sin ecuación de regresión publicada y validada por pares. | Usa la misma relación 3.5 × velocidad que VAM-EVAL. Menor respaldo científico que los tests anteriores; útil solo como referencia orientativa. |
| 6MWT (caminata 6 min) | Enright, P.L., Sherrill, D.L. (1998). Reference equations for the six-minute walk in healthy adults. *American Journal of Respiratory and Critical Care Medicine*, 158(5), 1384-1387. | No estima VO2max directamente: calcula el % de la distancia de referencia esperada según sexo/edad/peso/altura. Estándar clínico habitual. |
| Queens College Step Test | McArdle, W.D., Katch, F.I., Pechar, G.S., Jacobson, L., Ruck, S. (1972). | Asume equivalencia de costo de oxígeno entre el step test y la carrera en cinta; correlación r≈-0.75 con VO2max de laboratorio. |
| Harvard Step Test | Brouha, L. et al. (1943). Harvard Fatigue Laboratories. | Correlación con VO2max moderada (r=0.6-0.8). La forma larga (3 lecturas de pulso) es más precisa que la forma corta (1 lectura). |
| Ruffier-Dickson | Ruffier, J-E. (1951); modificado por J. Dickson. | Es un índice de recuperación cardíaca tras esfuerzo, no una estimación directa de VO2max. Popular en Francia. |
| UKK 2km Walk Test | Oja, P., Laukkanen, R., Pasanen, M., Tyry, T., Vuori, I. (1991). A 2-km walking test for assessing the cardiorespiratory fitness of healthy adults. *International Journal of Sports Medicine*, 12(4), 356-362. | Diseñado para adultos de 20-65 años. Menos preciso en personas con sobrepeso/obesidad marcada o en atletas de alto rendimiento. |

## Generador de rutinas

| Elemento | Cita | Alcance / limitaciones |
|---|---|---|
| Landmarks de volumen (MEV/MAV/MRV) | Israetel, M. et al. (2019). Renaissance Periodization — *Training Volume Landmarks for Muscle Growth* (serie de artículos por grupo muscular). | Valores de referencia ampliamente citados y usados en programación de hipertrofia basada en evidencia, pero son promedios poblacionales: la tolerancia real al volumen varía mucho entre individuos y debe ajustarse con la experiencia propia. |

**Nota sobre la lógica del split:** el reparto de sets por sesión (sets/semana ÷ frecuencia del grupo en el split elegido) y el armado de las plantillas de split (Full Body, Push/Pull/Legs, Upper/Lower, etc.) son una síntesis práctica de EntrenaLab que aplica los landmarks de Israetel de forma operativa — no son en sí mismos una fórmula publicada y validada, a diferencia de los landmarks de origen.

---

**Nota general:** todas estas ecuaciones son estimaciones poblacionales. Ninguna reemplaza una evaluación médica, un test de laboratorio (ergoespirometría, DEXA) o el criterio de un profesional certificado en ciencias del deporte.

## Herramienta de entrenador e informes PDF

No son fórmulas propias: la "Herramienta entrenador" reutiliza las mismas fórmulas de 1RM y el mismo generador de rutinas ya documentados arriba, combinados en una única ficha de cliente. La exportación a PDF se genera 100% en el navegador con [jsPDF](https://github.com/parallax/jsPDF) v2.5.2 + [jspdf-autotable](https://github.com/simonbengtsson/jsPDF-AutoTable) v3.8.2, vendorizadas en `vendor/` (ver `vendor/NOTICE.md`), sin backend, sin límite de uso y sin requerir conexión a internet.
