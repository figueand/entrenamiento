import { describe, it, expect } from 'vitest';
import {
  cooperTest, courseNavette, vamEval, fiveMinuteTest, sixMinuteWalkTest,
  queensStepTest, harvardStepTestShort, harvardStepTestLong, classifyHarvardIndex,
  ruffierDickson, classifyRuffier, ukkWalkTest, classifyVO2max,
} from '../js/formulas/fieldTests.js';

describe('cooperTest', () => {
  it('computes VO2max from 12-min distance', () => {
    // 2400m → (2400-504.9)/44.73 = 42.38
    expect(cooperTest(2400).vo2max).toBeCloseTo(42.4, 1);
  });
  it('rejects invalid distance', () => {
    expect(() => cooperTest(0)).toThrow();
  });
});

describe('courseNavette', () => {
  it('computes speed and VO2max for a given stage/age', () => {
    const result = courseNavette(8, 25); // speed = 8 + 8*0.5 = 12 km/h, age capped at 18
    expect(result.speed).toBe(12);
    expect(result.vo2max).toBeGreaterThan(30);
  });
});

describe('vamEval', () => {
  it('computes MAS and VO2max = 3.5 * MAS', () => {
    const result = vamEval(16); // MAS = 8 + 16*0.5 = 16 km/h
    expect(result.mas).toBe(16);
    expect(result.vo2max).toBe(56);
  });
});

describe('fiveMinuteTest', () => {
  it('computes MAS from distance/time and VO2max = 3.5 * MAS', () => {
    // 1500m in 5min → 18 km/h
    const result = fiveMinuteTest(1500);
    expect(result.mas).toBe(18);
    expect(result.vo2max).toBe(63);
  });
});

describe('sixMinuteWalkTest', () => {
  it('computes predicted distance and % predicted (male)', () => {
    const result = sixMinuteWalkTest(600, 40, 80, 175, 'male');
    // predicted = 7.57*175 - 5.02*40 - 1.76*80 - 309 = 1324.75-200.8-140.8-309=674.15
    expect(result.predictedDistance).toBeCloseTo(674, 0);
    expect(result.percentPredicted).toBeGreaterThan(80);
  });
});

describe('queensStepTest', () => {
  it('computes VO2max for men and women', () => {
    expect(queensStepTest(150, 'male').vo2max).toBeCloseTo(48.33, 1);
    expect(queensStepTest(150, 'female').vo2max).toBeCloseTo(38.1, 1);
  });
});

describe('harvardStepTest', () => {
  it('short form matches known example', () => {
    const result = harvardStepTestShort(300, 90);
    expect(result.index).toBeCloseTo((100 * 300) / (5.5 * 90), 1);
  });
  it('long form matches known worked example', () => {
    const result = harvardStepTestLong(300, 90, 65, 45);
    expect(result.index).toBeCloseTo(75, 0);
  });
  it('classifyHarvardIndex maps ranges', () => {
    expect(classifyHarvardIndex(50)).toBe('Pobre');
    expect(classifyHarvardIndex(95)).toBe('Excelente');
  });
});

describe('ruffierDickson', () => {
  it('computes both indexes', () => {
    const result = ruffierDickson(70, 140, 90);
    // ruffier = (70+140+90-200)/10 = 10
    expect(result.ruffierIndex).toBe(10);
    // dickson = ((140-70)+2*(90-70))/10 = (70+40)/10 = 11
    expect(result.dicksonIndex).toBe(11);
  });
  it('classifyRuffier maps ranges', () => {
    expect(classifyRuffier(-1)).toBe('Excelente');
    expect(classifyRuffier(20)).toBe('Mala');
  });
});

describe('ukkWalkTest', () => {
  it('matches the tester\'s guide worked example (female)', () => {
    // 17.50 min, HR 145, age 40, BMI 23 (peso/altura ya resuelto en el ejemplo oficial)
    // VO2max = 116.2 - 2.98*17.50 - 0.11*145 - 0.14*40 - 0.39*23 = 33.5
    const weightKg = 75;
    const heightCm = 180.6; // BMI = 75/1.806^2 ≈ 23.0 (aprox. al ejemplo oficial)
    const result = ukkWalkTest(17.5, 145, 40, weightKg, heightCm, 'female');
    expect(result.vo2max).toBeCloseTo(33.5, 0);
  });
});

describe('classifyVO2max', () => {
  it('maps ranges to labels', () => {
    expect(classifyVO2max(25)).toBe('Baja');
    expect(classifyVO2max(65)).toBe('Excelente');
  });
});
