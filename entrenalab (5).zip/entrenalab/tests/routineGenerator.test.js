import { describe, it, expect } from 'vitest';
import { generateRoutine, weeklyTargetSets, VOLUME_LANDMARKS } from '../js/formulas/routineGenerator.js';

describe('weeklyTargetSets', () => {
  const chest = VOLUME_LANDMARKS.chest;

  it('uses MEV for beginners regardless of goal (hypertrophy)', () => {
    expect(weeklyTargetSets(chest, 'beginner', 'hypertrophy')).toBe(chest.mev);
  });

  it('uses midpoint of MAV range for intermediate hypertrophy', () => {
    const expected = Math.round((chest.mavMin + chest.mavMax) / 2);
    expect(weeklyTargetSets(chest, 'intermediate', 'hypertrophy')).toBe(expected);
  });

  it('advanced hypertrophy target sits between MAV max and MRV', () => {
    const target = weeklyTargetSets(chest, 'advanced', 'hypertrophy');
    expect(target).toBeGreaterThan(chest.mavMax);
    expect(target).toBeLessThanOrEqual(chest.mrv);
  });

  it('strength target is lower than hypertrophy target for the same level', () => {
    const strength = weeklyTargetSets(chest, 'intermediate', 'strength');
    const hypertrophy = weeklyTargetSets(chest, 'intermediate', 'hypertrophy');
    expect(strength).toBeLessThan(hypertrophy);
  });

  it('generalFitness target stays at or below MEV', () => {
    expect(weeklyTargetSets(chest, 'beginner', 'generalFitness')).toBeLessThanOrEqual(chest.mev);
  });

  it('never returns a target below MV for strength', () => {
    const target = weeklyTargetSets(chest, 'beginner', 'strength');
    expect(target).toBeGreaterThanOrEqual(chest.mv);
  });
});

describe('generateRoutine', () => {
  it('rejects invalid goal/level/daysPerWeek', () => {
    expect(() => generateRoutine({ goal: 'bad', level: 'beginner', daysPerWeek: 3 })).toThrow();
    expect(() => generateRoutine({ goal: 'hypertrophy', level: 'bad', daysPerWeek: 3 })).toThrow();
    expect(() => generateRoutine({ goal: 'hypertrophy', level: 'beginner', daysPerWeek: 7 })).toThrow();
  });

  it('produces exactly daysPerWeek days for each valid split', () => {
    [2, 3, 4, 5, 6].forEach((daysPerWeek) => {
      const routine = generateRoutine({ goal: 'hypertrophy', level: 'intermediate', daysPerWeek });
      expect(routine.days).toHaveLength(daysPerWeek);
    });
  });

  it('every day has at least one exercise/muscle group', () => {
    const routine = generateRoutine({ goal: 'hypertrophy', level: 'intermediate', daysPerWeek: 3 });
    routine.days.forEach((day) => {
      expect(day.exercises.length).toBeGreaterThan(0);
    });
  });

  it('volumeSummary sets per session are always at least 1', () => {
    const routine = generateRoutine({ goal: 'generalFitness', level: 'beginner', daysPerWeek: 2 });
    routine.volumeSummary.forEach((v) => {
      expect(v.setsPerSession).toBeGreaterThanOrEqual(1);
    });
  });

  it('a muscle group trained on 2 days splits its weekly target across both sessions', () => {
    const routine = generateRoutine({ goal: 'hypertrophy', level: 'intermediate', daysPerWeek: 4 });
    const chestSummary = routine.volumeSummary.find((v) => v.key === 'chest');
    expect(chestSummary.frequency).toBe(2); // Upper A + Upper B
    expect(chestSummary.actualWeekly).toBe(chestSummary.setsPerSession * 2);
  });

  it('includes abs sessions bounded by the number of training days', () => {
    const routine = generateRoutine({ goal: 'hypertrophy', level: 'intermediate', daysPerWeek: 2 });
    const absSummary = routine.volumeSummary.find((v) => v.key === 'abs');
    expect(absSummary.frequency).toBeLessThanOrEqual(2);
  });

  it('reflects goal-specific rep ranges in every exercise', () => {
    const routine = generateRoutine({ goal: 'strength', level: 'beginner', daysPerWeek: 3 });
    routine.days.forEach((day) => {
      day.exercises.forEach((ex) => {
        expect(ex.reps).toBe('3-6');
      });
    });
  });
});
