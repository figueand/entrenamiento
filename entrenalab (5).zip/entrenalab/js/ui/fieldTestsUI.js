/**
 * js/ui/fieldTestsUI.js
 * Conecta el selector de protocolo y el formulario dinámico de la vista
 * "Tests de campo" con js/formulas/fieldTests.js.
 */

import * as FT from '../formulas/fieldTests.js';
import { formulaTags, fmt, showError } from './refUtils.js';

const TESTS = {
  cooper: {
    label: 'Cooper (12 min)',
    fields: [
      { id: 'distance', label: 'Distancia recorrida (m)', type: 'number', value: 2400, step: 1 },
    ],
    run: (v) => {
      const { vo2max } = FT.cooperTest(v.distance);
      return { vo2max, extra: [] };
    },
    citation: 'Cooper (1968)',
  },
  navette: {
    label: 'Course Navette (Léger)',
    fields: [
      { id: 'stage', label: 'Último palier completado', type: 'number', value: 8, step: 0.5 },
      { id: 'age', label: 'Edad (años)', type: 'number', value: 25, step: 1 },
    ],
    run: (v) => {
      const { speed, vo2max } = FT.courseNavette(v.stage, v.age);
      return { vo2max, extra: [`Velocidad final: ${fmt(speed, 1)} km/h`] };
    },
    citation: 'Léger et al. (1988)',
  },
  vameval: {
    label: 'VAM-EVAL',
    fields: [
      { id: 'stage', label: 'Último palier completado', type: 'number', value: 16, step: 0.5 },
    ],
    run: (v) => {
      const { mas, vo2max } = FT.vamEval(v.stage);
      return { vo2max, extra: [`VMA: ${fmt(mas, 1)} km/h`] };
    },
    citation: 'Cazorla & Léger (1993)',
  },
  fiveMin: {
    label: 'Test de 5 minutos',
    fields: [
      { id: 'distance', label: 'Distancia recorrida en 5 min (m)', type: 'number', value: 1500, step: 1 },
    ],
    run: (v) => {
      const { mas, vo2max } = FT.fiveMinuteTest(v.distance);
      return { vo2max, extra: [`VMA estimada: ${fmt(mas, 2)} km/h`, 'Heurística de campo, no una ecuación validada en literatura revisada por pares.'] };
    },
    citation: 'Heurística de campo (VMA × 3.5)',
  },
  sixMWT: {
    label: '6MWT (caminata de 6 min)',
    fields: [
      { id: 'distance', label: 'Distancia caminada (m)', type: 'number', value: 550, step: 1 },
      { id: 'age', label: 'Edad (años)', type: 'number', value: 40, step: 1 },
      { id: 'weight', label: 'Peso (kg)', type: 'number', value: 75, step: 0.1 },
      { id: 'height', label: 'Altura (cm)', type: 'number', value: 170, step: 1 },
      { id: 'sex', label: 'Sexo biológico', type: 'radio', options: [['male', 'Masculino'], ['female', 'Femenino']], value: 'male' },
    ],
    run: (v) => {
      const { predictedDistance, percentPredicted } = FT.sixMinuteWalkTest(v.distance, v.age, v.weight, v.height, v.sex);
      return {
        vo2max: null,
        headline: `${fmt(percentPredicted, 1)}%`,
        headlineUnit: 'de la distancia de referencia',
        extra: [`Distancia de referencia esperada: ${predictedDistance} m`],
      };
    },
    citation: 'Enright & Sherrill (1998)',
  },
  queens: {
    label: 'Queens College Step Test',
    fields: [
      { id: 'hr', label: 'FC de recuperación (lpm, conteo 15s × 4)', type: 'number', value: 150, step: 1 },
      { id: 'sex', label: 'Sexo biológico', type: 'radio', options: [['male', 'Masculino'], ['female', 'Femenino']], value: 'male' },
    ],
    run: (v) => {
      const { vo2max } = FT.queensStepTest(v.hr, v.sex);
      return { vo2max, extra: [] };
    },
    citation: 'McArdle et al. (1972)',
  },
  harvard: {
    label: 'Harvard Step Test',
    fields: [
      { id: 'duration', label: 'Duración del ejercicio (s)', type: 'number', value: 300, step: 1 },
      { id: 'p1', label: 'Pulso 1–1.5 min (conteo 30s)', type: 'number', value: 90, step: 1 },
      { id: 'p2', label: 'Pulso 2–2.5 min (opcional, forma larga)', type: 'number', value: '', step: 1, optional: true },
      { id: 'p3', label: 'Pulso 3–3.5 min (opcional, forma larga)', type: 'number', value: '', step: 1, optional: true },
    ],
    run: (v) => {
      const useLong = v.p2 !== '' && v.p3 !== '' && v.p2 != null && v.p3 != null;
      const { index } = useLong
        ? FT.harvardStepTestLong(v.duration, v.p1, v.p2, v.p3)
        : FT.harvardStepTestShort(v.duration, v.p1);
      return {
        vo2max: null,
        headline: fmt(index, 1),
        headlineUnit: 'índice',
        extra: [`Forma ${useLong ? 'larga' : 'corta'}`, `Clasificación: ${FT.classifyHarvardIndex(index)}`],
      };
    },
    citation: 'Brouha et al. (1943)',
  },
  ruffier: {
    label: 'Ruffier-Dickson',
    fields: [
      { id: 'p0', label: 'FC de reposo (P0)', type: 'number', value: 70, step: 1 },
      { id: 'p1', label: 'FC post-esfuerzo (P1)', type: 'number', value: 140, step: 1 },
      { id: 'p2', label: 'FC a 1 min de recuperación (P2)', type: 'number', value: 90, step: 1 },
    ],
    run: (v) => {
      const { ruffierIndex, dicksonIndex } = FT.ruffierDickson(v.p0, v.p1, v.p2);
      return {
        vo2max: null,
        headline: fmt(ruffierIndex, 2),
        headlineUnit: 'índice de Ruffier',
        extra: [`Índice de Dickson: ${fmt(dicksonIndex, 2)}`, `Clasificación: ${FT.classifyRuffier(ruffierIndex)}`],
      };
    },
    citation: 'Ruffier (1951) · Dickson',
  },
  ukk: {
    label: 'UKK 2km Walk Test',
    fields: [
      { id: 'time', label: 'Tiempo en caminar 2 km (min)', type: 'number', value: 17.5, step: 0.1 },
      { id: 'hr', label: 'FC al finalizar (lpm)', type: 'number', value: 130, step: 1 },
      { id: 'age', label: 'Edad (años)', type: 'number', value: 35, step: 1 },
      { id: 'weight', label: 'Peso (kg)', type: 'number', value: 75, step: 0.1 },
      { id: 'height', label: 'Altura (cm)', type: 'number', value: 175, step: 1 },
      { id: 'sex', label: 'Sexo biológico', type: 'radio', options: [['male', 'Masculino'], ['female', 'Femenino']], value: 'male' },
    ],
    run: (v) => {
      const { bmi, vo2max } = FT.ukkWalkTest(v.time, v.hr, v.age, v.weight, v.height, v.sex);
      return { vo2max, extra: [`IMC calculado: ${fmt(bmi, 1)}`] };
    },
    citation: 'Oja et al. (1991)',
  },
};

function fieldHTML(f) {
  if (f.type === 'radio') {
    return `
      <div>
        <label>${f.label}</label>
        <div class="radio-group">
          ${f.options.map(([val, text]) => `
            <label><input type="radio" name="ft-${f.id}" value="${val}" ${val === f.value ? 'checked' : ''}> ${text}</label>
          `).join('')}
        </div>
      </div>
    `;
  }
  return `
    <div>
      <label for="ft-${f.id}">${f.label}</label>
      <input type="number" id="ft-${f.id}" step="${f.step}" value="${f.value}" ${f.optional ? '' : 'required'}>
    </div>
  `;
}

function readValues(fields) {
  const values = {};
  fields.forEach((f) => {
    if (f.type === 'radio') {
      const input = document.querySelector(`input[name="ft-${f.id}"]:checked`);
      values[f.id] = input ? input.value : null;
    } else {
      const raw = document.getElementById(`ft-${f.id}`).value;
      values[f.id] = raw === '' ? '' : parseFloat(raw);
    }
  });
  return values;
}

export function initFieldTests() {
  const select = document.getElementById('ft-select');
  const formContainer = document.getElementById('ft-form-fields');
  const form = document.getElementById('form-fieldtest');
  const result = document.getElementById('result-fieldtest');
  if (!select) return;

  select.innerHTML = Object.entries(TESTS)
    .map(([key, t]) => `<option value="${key}">${t.label}</option>`)
    .join('');

  function renderFields() {
    const test = TESTS[select.value];
    formContainer.innerHTML = test.fields.map(fieldHTML).join('');
    result.classList.remove('visible');
  }

  select.addEventListener('change', renderFields);
  renderFields();

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const test = TESTS[select.value];
    try {
      const values = readValues(test.fields);
      const out = test.run(values);

      const headline = out.vo2max != null ? fmt(out.vo2max, 1) : out.headline;
      const unit = out.vo2max != null ? 'ml/kg/min' : (out.headlineUnit || '');
      const classification = out.vo2max != null ? FT.classifyVO2max(out.vo2max) : null;

      result.classList.add('visible');
      result.innerHTML = `
        <div class="readout-label">${test.label} — resultado</div>
        <div class="readout-value">${headline}<span class="unit">${unit}</span></div>
        ${classification ? `<div style="font-size:0.8rem; opacity:0.85; margin-bottom:0.5rem;">${classification}</div>` : ''}
        ${out.extra && out.extra.length ? `<ul style="margin:0.4rem 0 0.7rem; padding-left:1.1rem; font-size:0.85rem;">${out.extra.map((e) => `<li>${e}</li>`).join('')}</ul>` : ''}
        <div>${formulaTags([test.citation])}</div>
      `;
    } catch (err) {
      showError(result, err.message);
    }
  });
}
