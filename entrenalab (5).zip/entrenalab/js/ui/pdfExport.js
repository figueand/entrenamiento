/**
 * js/ui/pdfExport.js
 * Generación de informes PDF 100% client-side con jsPDF + jspdf-autotable
 * (vendorizados en vendor/, cargados como <script> local en index.html —
 * ver vendor/NOTICE.md). Sin backend, sin límite de uso, sin conexión a
 * internet requerida para exportar.
 *
 * Expone un builder simple para armar informes de una o varias secciones
 * (encabezado, tabla clave-valor, tabla de datos) reutilizado por las
 * distintas vistas (1RM, rutina, herramienta de entrenador).
 */

const BRAND_COLOR = [29, 69, 54]; // var(--accent-strong) en RGB

function getJsPDF() {
  if (!window.jspdf || !window.jspdf.jsPDF) {
    throw new Error('jsPDF no está disponible. Verificá que vendor/jspdf.umd.min.js se haya cargado correctamente.');
  }
  return window.jspdf.jsPDF;
}

function addBrandHeader(doc, { title, subtitle, whiteLabelName }) {
  const pageWidth = doc.internal.pageSize.getWidth();
  doc.setFillColor(...BRAND_COLOR);
  doc.rect(0, 0, pageWidth, 26, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text(whiteLabelName || 'EntrenaLab', 14, 12);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text('Informe generado en el navegador · sin backend', 14, 19);

  doc.setTextColor(20, 20, 20);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text(title, 14, 38);
  if (subtitle) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(90, 90, 90);
    doc.text(subtitle, 14, 45);
  }
  return 52; // próxima posición Y libre
}

function addKeyValueTable(doc, startY, rows) {
  doc.autoTable({
    startY,
    theme: 'plain',
    styles: { fontSize: 10, cellPadding: 1.5 },
    columnStyles: { 0: { fontStyle: 'bold', cellWidth: 60 } },
    body: rows,
  });
  return doc.lastAutoTable.finalY + 6;
}

function addDataTable(doc, startY, { head, body, title }) {
  let y = startY;
  if (title) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(20, 20, 20);
    doc.text(title, 14, y);
    y += 5;
  }
  doc.autoTable({
    startY: y,
    head: [head],
    body,
    theme: 'striped',
    headStyles: { fillColor: BRAND_COLOR, fontSize: 9 },
    bodyStyles: { fontSize: 9 },
    margin: { left: 14, right: 14 },
  });
  return doc.lastAutoTable.finalY + 8;
}

function addFooter(doc) {
  const pageCount = doc.internal.getNumberOfPages();
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(140, 140, 140);
    doc.text(
      'EntrenaLab · Herramienta educativa e informativa. No reemplaza una evaluación médica ni el criterio de un profesional certificado.',
      14,
      pageHeight - 8,
    );
    doc.text(`${i}/${pageCount}`, pageWidth - 18, pageHeight - 8);
  }
}

/**
 * Construye y descarga un PDF a partir de una lista de secciones.
 * @param {{title: string, subtitle?: string, whiteLabelName?: string, filename: string, sections: Array}} report
 * Cada sección puede ser:
 *  - { type: 'keyValue', rows: [[label, value], ...] }
 *  - { type: 'table', title?: string, head: string[], body: string[][] }
 */
export function exportReportPDF(report) {
  const JsPDF = getJsPDF();
  const doc = new JsPDF({ unit: 'mm', format: 'a4' });

  let y = addBrandHeader(doc, report);

  report.sections.forEach((section) => {
    const pageHeight = doc.internal.pageSize.getHeight();
    if (y > pageHeight - 40) {
      doc.addPage();
      y = 16;
    }
    if (section.type === 'keyValue') {
      y = addKeyValueTable(doc, y, section.rows);
    } else if (section.type === 'table') {
      y = addDataTable(doc, y, section);
    }
  });

  addFooter(doc);
  doc.save(report.filename || 'entrenalab-informe.pdf');
}
