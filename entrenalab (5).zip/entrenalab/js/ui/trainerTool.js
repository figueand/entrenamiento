/**
 * js/ui/trainerTool.js
 * "Herramienta entrenador": ficha rápida de cliente en un solo formulario.
 * Reusa las fórmulas de 1RM y el generador de rutinas ya existentes,
 * y arma un único informe PDF combinado con los datos del cliente.
 */

import { estimateOneRM, buildLoadTable } from '../formulas/oneRM.js';
import { generateRoutine, GOALS } from '../formulas/routineGenerator.js';
import { buildRoutineSections } from './routineBuilder.js';
import { formulaTags, fmt, showError } from './refUtils.js';
import { exportReportPDF } from './pdfExport.js';

function el(id) { return document.getElementById(id); }

export function initTrainerTool() {
  const form = el('form-trainer');
  const result = el('result-trainer');
  if (!form) return;

  const goalSelect = el('trainer-goal');
  goalSelect.innerHTML = Object.entries(GOALS)
    .map(([key, g]) => `<option value="${key}">${g.label}</option>`)
    .join('');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    try {
      const clientName = el('trainer-name').value.trim() || 'Cliente sin nombre';
      const coachName = el('trainer-coach').value.trim();
      const liftWeight = parseFloat(el('trainer-lift-weight').value);
      const liftReps = parseInt(el('trainer-lift-reps').value, 10);
      const liftName = el('trainer-lift-name').value.trim() || 'Ejercicio';

      const goal = goalSelect.value;
      const level = document.querySelector('input[name="trainer-level"]:checked')?.value;
      const daysPerWeek = parseInt(el('trainer-days').value, 10);
      if (!level) throw new RangeError('Seleccioná el nivel del cliente.');

      const estimates = estimateOneRM(liftWeight, liftReps);
      const table = buildLoadTable(estimates.average);
      const routine = generateRoutine({ goal, level, daysPerWeek });

      result.classList.add('visible');
      result.innerHTML = `
        <div class="readout-label">Ficha de ${clientName}</div>
        <div class="readout-value" style="font-size:1.6rem;">${liftName}: ${fmt(estimates.average, 1)}<span class="unit">kg (1RM est.)</span></div>
        <div style="margin:0.4rem 0 0.8rem;">${formulaTags(['Promedio de 5 fórmulas de 1RM', 'Israetel et al. (2019)'])}</div>
        <p style="font-size:0.85rem; opacity:0.9;">Rutina asignada: ${routine.splitName} · ${routine.goalLabel} · ${routine.daysPerWeek} días/semana.</p>
        <table class="data-table" style="color: var(--ink); background: var(--paper-raised);">
          <thead><tr><th>Reps</th><th>% 1RM</th><th>Carga</th></tr></thead>
          <tbody>
            ${table.slice(0, 6).map((row) => `<tr><td>${row.reps}</td><td>${row.percent}%</td><td>${fmt(row.load, 1)} kg</td></tr>`).join('')}
          </tbody>
        </table>
      `;

      const exportWrap = el('export-trainer-wrap');
      exportWrap.innerHTML = `<button type="button" id="export-trainer" class="ghost">↓ Exportar ficha en PDF</button>`;
      el('export-trainer').addEventListener('click', () => {
        exportReportPDF({
          title: `Ficha de entrenamiento — ${clientName}`,
          subtitle: `Generado el ${new Date().toLocaleDateString('es-AR')}`,
          whiteLabelName: coachName || undefined,
          filename: `entrenalab-ficha-${clientName.toLowerCase().replace(/\s+/g, '-')}.pdf`,
          sections: [
            {
              type: 'keyValue',
              rows: [
                ['Cliente', clientName],
                ['Ejercicio evaluado', liftName],
                ['Peso levantado', `${fmt(liftWeight, 1)} kg`],
                ['Repeticiones', String(liftReps)],
                ['1RM estimado (promedio)', `${fmt(estimates.average, 1)} kg`],
              ],
            },
            {
              type: 'table',
              title: 'Tabla de cargas por % 1RM',
              head: ['Reps', '% 1RM', 'Carga'],
              body: table.map((row) => [row.reps, `${row.percent}%`, `${fmt(row.load, 1)} kg`]),
            },
            ...buildRoutineSections(routine),
          ],
        });
      });
    } catch (err) {
      showError(result, err.message);
    }
  });
}
