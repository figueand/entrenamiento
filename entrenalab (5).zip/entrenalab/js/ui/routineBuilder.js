/**
 * js/ui/routineBuilder.js
 * Conecta el formulario de la vista "Generador de rutinas" con
 * js/formulas/routineGenerator.js y renderiza el split resultante.
 */

import { generateRoutine, GOALS } from '../formulas/routineGenerator.js';
import { formulaTags, showError } from './refUtils.js';
import { exportReportPDF } from './pdfExport.js';

function el(id) { return document.getElementById(id); }

export function buildRoutineSections(routine) {
  return [
    {
      type: 'keyValue',
      rows: [
        ['Split', routine.splitName],
        ['Objetivo', routine.goalLabel],
        ['Días/semana', String(routine.daysPerWeek)],
      ],
    },
    ...routine.days.map((day) => ({
      type: 'table',
      title: `Día ${day.dayNumber} — ${day.label}`,
      head: ['Grupo muscular', 'Sets', 'Reps', 'RIR', 'Descanso'],
      body: day.exercises.map((ex) => [ex.muscle, ex.sets, ex.reps, ex.rir, ex.rest]),
    })),
    {
      type: 'table',
      title: 'Resumen de volumen semanal',
      head: ['Grupo', 'Frecuencia/sem', 'Sets/sem objetivo', 'Sets/sem programados'],
      body: routine.volumeSummary.map((v) => [v.label, `${v.frequency}×`, v.weeklyTarget, v.actualWeekly]),
    },
  ];
}

function renderRoutine(container, routine) {
  container.classList.add('visible');
  container.innerHTML = `
    <div class="readout-label">${routine.splitName} · ${routine.goalLabel} · ${routine.daysPerWeek} días/semana</div>
    <div style="margin: 0.6rem 0 1rem;">${formulaTags(['Israetel et al. (2019) — landmarks MEV/MAV/MRV'])}</div>

    <div class="stack" style="gap: 1rem;">
      ${routine.days.map((day) => `
        <div style="border-top: 1px dashed rgba(63,174,127,0.3); padding-top: 0.8rem;">
          <div style="font-weight:700; margin-bottom:0.4rem;">Día ${day.dayNumber} — ${day.label}</div>
          <table class="data-table" style="color: var(--ink); background: var(--paper-raised);">
            <thead><tr><th>Grupo muscular</th><th>Sets</th><th>Reps</th><th>RIR</th><th>Descanso</th></tr></thead>
            <tbody>
              ${day.exercises.map((ex) => `
                <tr><td>${ex.muscle}</td><td>${ex.sets}</td><td>${ex.reps}</td><td>${ex.rir}</td><td>${ex.rest}</td></tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `).join('')}
    </div>
  `;

  const summaryContainer = el('routine-summary');
  summaryContainer.innerHTML = `
    <table class="data-table">
      <thead><tr><th>Grupo</th><th>Frecuencia/sem</th><th>Sets/sem objetivo</th><th>Sets/sem programados</th></tr></thead>
      <tbody>
        ${routine.volumeSummary.map((v) => `
          <tr><td>${v.label}</td><td>${v.frequency}×</td><td>${v.weeklyTarget}</td><td>${v.actualWeekly}</td></tr>
        `).join('')}
      </tbody>
    </table>
  `;

  const exportWrap = el('export-routine-wrap');
  exportWrap.innerHTML = `<button type="button" id="export-routine" class="ghost">↓ Exportar PDF</button>`;
  el('export-routine').addEventListener('click', () => {
    exportReportPDF({
      title: 'Rutina de entrenamiento',
      subtitle: `${routine.splitName} · ${routine.goalLabel}`,
      filename: 'entrenalab-rutina.pdf',
      sections: buildRoutineSections(routine),
    });
  });
}

export function initRoutineBuilder() {
  const form = el('form-routine');
  const result = el('result-routine');
  if (!form) return;

  const goalSelect = el('routine-goal');
  goalSelect.innerHTML = Object.entries(GOALS)
    .map(([key, g]) => `<option value="${key}">${g.label}</option>`)
    .join('');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    try {
      const goal = goalSelect.value;
      const level = document.querySelector('input[name="routine-level"]:checked')?.value;
      const daysPerWeek = parseInt(el('routine-days').value, 10);
      if (!level) throw new RangeError('Seleccioná tu nivel de entrenamiento.');

      const routine = generateRoutine({ goal, level, daysPerWeek });
      renderRoutine(result, routine);
    } catch (err) {
      showError(result, err.message);
    }
  });
}
