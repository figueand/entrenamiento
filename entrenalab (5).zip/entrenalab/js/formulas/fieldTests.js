/**
 * js/formulas/fieldTests.js
 * Tests de campo de resistencia cardiorrespiratoria: estimación de VO2máx
 * (o de un índice de aptitud cardiovascular) a partir de protocolos que no
 * requieren laboratorio.
 *
 * Fuentes (ver REFERENCIAS.md para detalle completo):
 * - Cooper, K.H. (1968). A means of assessing maximal oxygen intake. JAMA, 203, 201-204.
 * - Léger, L.A., Mercier, D., Gadoury, C., Lambert, J. (1988). The multistage
 *   20 metre shuttle run test for aerobic fitness. J Sports Sci, 6(2), 93-101.
 * - Cazorla, G., Léger, L. (1993). VAMEVAL — test de vitesse maximale aérobie.
 * - Enright, P.L., Sherrill, D.L. (1998). Reference equations for the
 *   six-minute walk in healthy adults. Am J Respir Crit Care Med, 158(5), 1384-1387.
 * - McArdle, W.D. et al. (1972). Queens College Step Test.
 * - Brouha, L. et al. (1943). Harvard Step Test, Harvard Fatigue Laboratories.
 * - Ruffier, J-E. (1951); Dickson, J. Ruffier-Dickson Index.
 * - Oja, P., Laukkanen, R., Pasanen, M., Tyry, T., Vuori, I. (1991). A 2-km
 *   walking test for assessing the cardiorespiratory fitness of healthy
 *   adults. Int J Sports Med, 12(4), 356-362.
 */

function assertPositive(value, name) {
  if (!Number.isFinite(value) || value <= 0) {
    throw new RangeError(`${name} debe ser un número mayor a 0.`);
  }
}

/* --------------------------- 1. Cooper (12 min) --------------------------- */
/** distanceMeters: distancia recorrida en 12 minutos, en metros. */
export function cooperTest(distanceMeters) {
  assertPositive(distanceMeters, 'La distancia');
  const vo2max = (distanceMeters - 504.9) / 44.73;
  return { vo2max: Math.round(vo2max * 10) / 10 };
}

/* ------------------------ 2. Course Navette (Léger) ------------------------ */
/**
 * stage: último palier completado (empieza en 1 = 8.5 km/h, +0.5 km/h por palier).
 * age: edad del sujeto (se limita a 18 para adultos, según la validación original).
 */
export function courseNavette(stage, age) {
  assertPositive(stage, 'El palier');
  assertPositive(age, 'La edad');
  const speed = 8 + stage * 0.5; // km/h del último palier completado
  const effectiveAge = Math.min(age, 18);
  const vo2max = 31.025 + 3.238 * speed - 3.248 * effectiveAge + 0.1536 * effectiveAge * speed;
  return { speed, vo2max: Math.round(vo2max * 10) / 10 };
}

/* ------------------------------ 3. VAM-EVAL -------------------------------- */
/** stage: último palier completado (empieza en 1 = 8.5 km/h, +0.5 km/h/min). */
export function vamEval(stage) {
  assertPositive(stage, 'El palier');
  const mas = 8 + stage * 0.5; // Vitesse Maximale Aérobie (km/h)
  const vo2max = 3.5 * mas;
  return { mas, vo2max: Math.round(vo2max * 10) / 10 };
}

/* ----------------------------- 4. Test de 5 min ----------------------------- */
/**
 * distanceMeters: distancia máxima recorrida corriendo en 5 minutos.
 * Heurística de campo (no una ecuación de regresión publicada y validada
 * como las anteriores): estima la VMA como la velocidad media sostenida y
 * aplica la misma relación velocidad→VO2max usada en VAM-EVAL (3.5 ml/kg/min
 * por km/h). Útil para estimar zonas de entrenamiento, con menor respaldo
 * de validación que Cooper, Course Navette o VAM-EVAL.
 */
export function fiveMinuteTest(distanceMeters) {
  assertPositive(distanceMeters, 'La distancia');
  const mas = (distanceMeters / 1000) / (5 / 60); // km/h
  const vo2max = 3.5 * mas;
  return { mas: Math.round(mas * 100) / 100, vo2max: Math.round(vo2max * 10) / 10 };
}

/* -------------------------------- 5. 6MWT ---------------------------------- */
/**
 * Test de caminata de 6 minutos. No estima VO2max directamente: calcula la
 * distancia de referencia esperada (Enright & Sherrill, 1998) y el % que
 * representa la distancia realmente caminada, el indicador clínico estándar.
 */
export function sixMinuteWalkTest(distanceMeters, age, weightKg, heightCm, sex) {
  assertPositive(distanceMeters, 'La distancia');
  assertPositive(age, 'La edad');
  assertPositive(weightKg, 'El peso');
  assertPositive(heightCm, 'La altura');
  if (sex !== 'male' && sex !== 'female') {
    throw new RangeError('sex debe ser "male" o "female".');
  }
  const predicted = sex === 'male'
    ? 7.57 * heightCm - 5.02 * age - 1.76 * weightKg - 309
    : 2.11 * heightCm - 2.29 * weightKg - 5.78 * age + 667;
  const percentPredicted = (distanceMeters / predicted) * 100;
  return {
    predictedDistance: Math.round(predicted),
    percentPredicted: Math.round(percentPredicted * 10) / 10,
  };
}

/* --------------------- 6. Queens College Step Test -------------------------- */
/** recoveryHR: frecuencia cardíaca de recuperación en lpm (conteo de 15s × 4). */
export function queensStepTest(recoveryHR, sex) {
  assertPositive(recoveryHR, 'La FC de recuperación');
  if (sex !== 'male' && sex !== 'female') {
    throw new RangeError('sex debe ser "male" o "female".');
  }
  const vo2max = sex === 'male'
    ? 111.33 - 0.42 * recoveryHR
    : 65.81 - 0.1847 * recoveryHR;
  return { vo2max: Math.round(vo2max * 10) / 10 };
}

/* ------------------------- 7. Harvard Step Test ----------------------------- */
/**
 * Forma corta: requiere solo el pulso del minuto 1 a 1.5 (conteo de 30s, sin multiplicar).
 * Forma larga: requiere los 3 pulsos (1-1.5min, 2-2.5min, 3-3.5min), cada uno
 * como conteo de 30s sin multiplicar.
 */
export function harvardStepTestShort(durationSeconds, pulse1) {
  assertPositive(durationSeconds, 'La duración');
  assertPositive(pulse1, 'El pulso');
  const index = (100 * durationSeconds) / (5.5 * pulse1);
  return { index: Math.round(index * 10) / 10 };
}

export function harvardStepTestLong(durationSeconds, pulse1, pulse2, pulse3) {
  assertPositive(durationSeconds, 'La duración');
  assertPositive(pulse1, 'El pulso 1');
  assertPositive(pulse2, 'El pulso 2');
  assertPositive(pulse3, 'El pulso 3');
  const index = (100 * durationSeconds) / (2 * (pulse1 + pulse2 + pulse3));
  return { index: Math.round(index * 10) / 10 };
}

export function classifyHarvardIndex(index) {
  if (index < 55) return 'Pobre';
  if (index < 65) return 'Baja';
  if (index < 80) return 'Media';
  if (index < 90) return 'Buena';
  return 'Excelente';
}

/* -------------------------- 8. Ruffier-Dickson ------------------------------ */
/**
 * P0: FC de reposo (lpm). P1: FC inmediatamente después de 30 sentadillas en
 * 45s (lpm). P2: FC 1 min después de terminado el ejercicio (lpm).
 */
export function ruffierDickson(p0, p1, p2) {
  assertPositive(p0, 'P0');
  assertPositive(p1, 'P1');
  assertPositive(p2, 'P2');
  const ruffierIndex = (p0 + p1 + p2 - 200) / 10;
  const dicksonIndex = ((p1 - 70) + 2 * (p2 - p0)) / 10;
  return {
    ruffierIndex: Math.round(ruffierIndex * 100) / 100,
    dicksonIndex: Math.round(dicksonIndex * 100) / 100,
  };
}

export function classifyRuffier(index) {
  if (index < 0) return 'Excelente';
  if (index <= 5) return 'Buena';
  if (index <= 10) return 'Media';
  if (index <= 15) return 'Baja';
  return 'Mala';
}

/* --------------------------- 9. UKK 2km Walk Test ---------------------------- */
/**
 * walkTimeMinutes: tiempo en caminar 2 km (minutos, con decimales).
 * heartRate: FC al finalizar la caminata (lpm).
 */
export function ukkWalkTest(walkTimeMinutes, heartRate, age, weightKg, heightCm, sex) {
  assertPositive(walkTimeMinutes, 'El tiempo de caminata');
  assertPositive(heartRate, 'La FC final');
  assertPositive(age, 'La edad');
  assertPositive(weightKg, 'El peso');
  assertPositive(heightCm, 'La altura');
  if (sex !== 'male' && sex !== 'female') {
    throw new RangeError('sex debe ser "male" o "female".');
  }
  const heightM = heightCm / 100;
  const bmi = weightKg / (heightM * heightM);
  const vo2max = sex === 'male'
    ? 184.9 - 4.65 * walkTimeMinutes - 0.22 * heartRate - 0.26 * age - 1.05 * bmi
    : 116.2 - 2.98 * walkTimeMinutes - 0.11 * heartRate - 0.14 * age - 0.39 * bmi;
  return { bmi: Math.round(bmi * 10) / 10, vo2max: Math.round(vo2max * 10) / 10 };
}

/** Clasificación genérica de VO2max (ml/kg/min) orientativa, no oficial. */
export function classifyVO2max(vo2max) {
  if (vo2max < 30) return 'Baja';
  if (vo2max < 40) return 'Regular';
  if (vo2max < 50) return 'Buena';
  if (vo2max < 60) return 'Muy buena';
  return 'Excelente';
}
