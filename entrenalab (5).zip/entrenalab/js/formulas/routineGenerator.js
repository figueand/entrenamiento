/**
 * js/formulas/routineGenerator.js
 * Genera un split semanal de entrenamiento distribuyendo el volumen
 * (sets/semana por grupo muscular) según los landmarks de volumen de
 * Israetel (MV/MEV/MAV/MRV), el objetivo y el nivel de la persona.
 *
 * Fuente de los landmarks (ver REFERENCIAS.md):
 * - Israetel, M. et al. (2019). Renaissance Periodization — Training
 *   Volume Landmarks for Muscle Growth (serie de artículos por grupo
 *   muscular). Valores de referencia ampliamente citados en la
 *   comunidad de hipertrofia basada en evidencia.
 *
 * La lógica de reparto de sets por sesión y de armado del split
 * (qué días entrena cada grupo) es una síntesis propia de EntrenaLab
 * aplicando esos landmarks de forma práctica — no es en sí misma una
 * fórmula publicada y validada, a diferencia de los landmarks de origen.
 */

export const VOLUME_LANDMARKS = {
  chest: { label: 'Pecho', mv: 8, mev: 10, mavMin: 12, mavMax: 20, mrv: 22 },
  back: { label: 'Espalda', mv: 8, mev: 10, mavMin: 14, mavMax: 22, mrv: 26 },
  shoulders: { label: 'Hombros', mv: 0, mev: 8, mavMin: 16, mavMax: 22, mrv: 26 },
  biceps: { label: 'Bíceps', mv: 5, mev: 8, mavMin: 14, mavMax: 20, mrv: 26 },
  triceps: { label: 'Tríceps', mv: 4, mev: 6, mavMin: 10, mavMax: 14, mrv: 18 },
  quads: { label: 'Cuádriceps', mv: 6, mev: 8, mavMin: 12, mavMax: 18, mrv: 20 },
  hamstrings: { label: 'Isquiotibiales', mv: 4, mev: 6, mavMin: 10, mavMax: 16, mrv: 20 },
  glutes: { label: 'Glúteos', mv: 0, mev: 4, mavMin: 4, mavMax: 12, mrv: 16 },
  calves: { label: 'Pantorrillas', mv: 6, mev: 8, mavMin: 12, mavMax: 16, mrv: 20 },
  abs: { label: 'Abdominales', mv: 0, mev: 0, mavMin: 16, mavMax: 20, mrv: 24, freqMin: 3, freqMax: 5 },
};

const PUSH = ['chest', 'shoulders', 'triceps'];
const PULL = ['back', 'biceps'];
const LEGS = ['quads', 'hamstrings', 'glutes', 'calves'];
const UPPER = ['chest', 'back', 'shoulders', 'biceps', 'triceps'];
const LOWER = ['quads', 'hamstrings', 'glutes', 'calves'];
const FULL_BODY = ['chest', 'back', 'shoulders', 'quads', 'hamstrings', 'glutes', 'biceps', 'triceps', 'calves'];

const SPLIT_TEMPLATES = {
  2: { name: 'Full Body', days: [{ label: 'Full Body A', muscles: FULL_BODY }, { label: 'Full Body B', muscles: FULL_BODY }] },
  3: { name: 'Push / Pull / Legs', days: [{ label: 'Push', muscles: PUSH }, { label: 'Pull', muscles: PULL }, { label: 'Legs', muscles: LEGS }] },
  4: {
    name: 'Upper / Lower',
    days: [
      { label: 'Upper A', muscles: UPPER },
      { label: 'Lower A', muscles: LOWER },
      { label: 'Upper B', muscles: UPPER },
      { label: 'Lower B', muscles: LOWER },
    ],
  },
  5: {
    name: 'Push / Pull / Legs + Upper / Lower',
    days: [
      { label: 'Push', muscles: PUSH },
      { label: 'Pull', muscles: PULL },
      { label: 'Legs', muscles: LEGS },
      { label: 'Upper', muscles: UPPER },
      { label: 'Lower', muscles: LOWER },
    ],
  },
  6: {
    name: 'Push / Pull / Legs × 2',
    days: [
      { label: 'Push A', muscles: PUSH },
      { label: 'Pull A', muscles: PULL },
      { label: 'Legs A', muscles: LEGS },
      { label: 'Push B', muscles: PUSH },
      { label: 'Pull B', muscles: PULL },
      { label: 'Legs B', muscles: LEGS },
    ],
  },
};

const GOAL_CONFIG = {
  hypertrophy: { label: 'Hipertrofia', reps: '8-12', rir: '1-3', rest: '60-90 s' },
  strength: { label: 'Fuerza', reps: '3-6', rir: '1-3', rest: '3-5 min' },
  generalFitness: { label: 'Salud / resistencia general', reps: '12-20', rir: '2-4', rest: '45-60 s' },
};

const LEVELS = ['beginner', 'intermediate', 'advanced'];

function assertValid(goal, level, daysPerWeek) {
  if (!GOAL_CONFIG[goal]) throw new RangeError(`goal inválido: ${goal}`);
  if (!LEVELS.includes(level)) throw new RangeError(`level inválido: ${level}`);
  if (!SPLIT_TEMPLATES[daysPerWeek]) throw new RangeError('daysPerWeek debe ser un número entre 2 y 6.');
}

/** Calcula el objetivo de sets semanales para un grupo muscular según nivel y objetivo. */
export function weeklyTargetSets(landmark, level, goal) {
  if (goal === 'generalFitness') {
    const table = { beginner: landmark.mv, intermediate: landmark.mev, advanced: Math.round(landmark.mev * 1.25) };
    return Math.max(0, table[level]);
  }
  if (goal === 'strength') {
    const base = {
      beginner: landmark.mev,
      intermediate: landmark.mavMin,
      advanced: Math.round((landmark.mavMin + landmark.mavMax) / 2),
    }[level];
    // Menos volumen que hipertrofia: la intensidad más alta exige más recuperación por set.
    return Math.max(landmark.mv, Math.round(base * 0.7));
  }
  // hypertrophy (default)
  const table = {
    beginner: landmark.mev,
    intermediate: Math.round((landmark.mavMin + landmark.mavMax) / 2),
    advanced: Math.round(landmark.mavMax + (landmark.mrv - landmark.mavMax) * 0.5),
  };
  return table[level];
}

/**
 * Genera el split semanal completo.
 * @param {{goal: 'hypertrophy'|'strength'|'generalFitness', level: 'beginner'|'intermediate'|'advanced', daysPerWeek: number}} params
 */
export function generateRoutine({ goal, level, daysPerWeek }) {
  assertValid(goal, level, daysPerWeek);
  const template = SPLIT_TEMPLATES[daysPerWeek];
  const goalConfig = GOAL_CONFIG[goal];

  // Sesiones de abdominales: entre freqMin y freqMax del landmark, acotado por los días disponibles.
  const absLandmark = VOLUME_LANDMARKS.abs;
  const absSessions = Math.min(daysPerWeek, Math.max(daysPerWeek >= absLandmark.freqMin ? absLandmark.freqMin : daysPerWeek, Math.min(daysPerWeek, absLandmark.freqMax)));

  const days = template.days.map((day, index) => ({
    ...day,
    muscles: index < absSessions ? [...day.muscles, 'abs'] : [...day.muscles],
  }));

  // Frecuencia semanal real de cada grupo muscular según el split armado.
  const frequency = {};
  days.forEach((day) => {
    day.muscles.forEach((key) => {
      frequency[key] = (frequency[key] || 0) + 1;
    });
  });

  // Sets objetivo por semana y por sesión, para cada grupo presente en el split.
  const volumeSummary = Object.entries(frequency).map(([key, freq]) => {
    const landmark = VOLUME_LANDMARKS[key];
    const weeklyTarget = weeklyTargetSets(landmark, level, goal);
    const setsPerSession = Math.max(1, Math.round(weeklyTarget / freq));
    return {
      key,
      label: landmark.label,
      frequency: freq,
      weeklyTarget,
      setsPerSession,
      actualWeekly: setsPerSession * freq,
    };
  });

  const setsByKey = Object.fromEntries(volumeSummary.map((v) => [v.key, v]));

  const fullDays = days.map((day, i) => ({
    dayNumber: i + 1,
    label: day.label,
    exercises: day.muscles.map((key) => ({
      muscle: setsByKey[key].label,
      sets: setsByKey[key].setsPerSession,
      reps: goalConfig.reps,
      rir: goalConfig.rir,
      rest: goalConfig.rest,
    })),
  }));

  return {
    splitName: template.name,
    goalLabel: goalConfig.label,
    daysPerWeek,
    days: fullDays,
    volumeSummary,
  };
}

export const GOALS = GOAL_CONFIG;
