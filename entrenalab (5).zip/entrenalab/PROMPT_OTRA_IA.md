# Prompt para continuar EntrenaLab en otra IA

Copiá y pegá esto tal cual como primer mensaje, adjuntando el `.zip` del proyecto (o subiendo la carpeta descomprimida si la herramienta lo permite):

---

Estoy retomando el desarrollo de **EntrenaLab**, una app web de cálculos de entrenamiento (HTML/CSS/JS puro, sin frameworks, sin backend). Te adjunto el proyecto completo en un .zip.

Antes de tocar nada, leé estos dos archivos del proyecto en este orden:
1. `README.md` — especificación funcional completa del proyecto.
2. `ESTADO_PROYECTO.md` — estado actual, arquitectura, decisiones de diseño y qué falta.

Reglas que quiero que respetes al seguir desarrollando:

1. **Arquitectura**: todo lo que va en `js/formulas/` debe ser JS puro, sin tocar `document`/`window`, para que se pueda testear con Vitest sin navegador simulado. La UI (`js/ui/`) solo hace wiring de DOM y nunca calcula nada por su cuenta.
2. **Cada fórmula nueva necesita**: (a) JSDoc en el código citando autor/año/publicación y una nota de alcance/limitaciones, (b) entrada correspondiente en `REFERENCIAS.md`, (c) entrada correspondiente en `js/ui/references.js` (pestaña "Referencias" de la app). Los tres deben quedar sincronizados.
3. **Verificá con búsqueda web cualquier coeficiente numérico o fórmula específica antes de codificarla** — no confíes en la memoria del modelo para constantes como las de DOTS/Wilks/Léger/UKK, son fáciles de confundir y el proyecto se presenta como "basado en evidencia".
4. **Tests**: cada módulo de `js/formulas/` tiene su archivo en `tests/` con Vitest. Si agregás o modificás una fórmula, agregá o actualizá su test. Corré `npm test` antes de dar algo por terminado.
5. **Diseño**: seguí el sistema de diseño ya definido en `css/styles.css` (identidad "cuaderno de laboratorio de rendimiento", variables CSS existentes, tipografías Space Grotesk/JetBrains Mono). No introduzcas un sistema de diseño nuevo sin que te lo pida explícitamente.
6. **No asumas que el código fue probado en navegador real** — todo lo anterior se validó con tests unitarios de lógica y revisión de código, no con click-testing real. Si podés correrlo en un navegador (headless o real), hacelo antes de asumir que algo visual funciona.

Los próximos pasos que tengo en mente son (elegí el que prefiera yo cuando te lo diga, no arranques sin confirmar):
- Vendorizar jsPDF/autotable para que la exportación a PDF funcione offline (hoy depende de un CDN).
- Sumar tests para los módulos de `js/ui/` (necesitaría configurar `jsdom` o `happy-dom` en Vitest).
- Alguna de las ideas del roadmap de monetización del `README.md`.

Confirmame que leíste ambos archivos y decime qué encontraste antes de proponer cambios.

---
